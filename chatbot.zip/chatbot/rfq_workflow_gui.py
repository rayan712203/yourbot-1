import importlib.util
import os
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BOT_PATH = os.path.join(SCRIPT_DIR, "rfq_workflow_bot (1).py")


def load_workflow_module(path: str):
    spec = importlib.util.spec_from_file_location("rfq_workflow_bot", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load workflow module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class TextRedirector:
    def __init__(self, text_widget, tag="stdout"):
        self.text_widget = text_widget
        self.tag = tag

    def write(self, message):
        if not message:
            return
        self.text_widget.after(0, self._append, message)

    def flush(self):
        pass

    def _append(self, message):
        self.text_widget.configure(state="normal")
        self.text_widget.insert(tk.END, message)
        self.text_widget.see(tk.END)
        self.text_widget.configure(state="disabled")


class RFQGui(tk.Tk):
    def __init__(self, workflow_module):
        super().__init__()
        self.workflow_module = workflow_module
        self.title("RFQ Workflow GUI")
        self.geometry("820x620")
        self.resizable(True, True)

        self.last_po = None
        self.last_po_json = None
        self.last_po_pdf = None
        self.last_rfq = None
        self.last_rfq_pdfs = []

        self._build_ui()

    def _build_ui(self):
        frame = tk.Frame(self)
        frame.pack(fill="x", padx=12, pady=10)

        tk.Label(frame, text="Document name:").grid(row=0, column=0, sticky="w")
        self.doc_entry = tk.Entry(frame, width=36)
        self.doc_entry.insert(0, "sample_requirement_doc.pdf")
        self.doc_entry.grid(row=0, column=1, sticky="w", padx=(6, 12))

        self.auto_var = tk.BooleanVar(value=True)
        tk.Checkbutton(frame, text="Auto select recommended vendor", variable=self.auto_var).grid(row=0, column=2, sticky="w")

        tk.Label(frame, text="Vendor selection (#):").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.vendor_entry = tk.Entry(frame, width=8)
        self.vendor_entry.grid(row=1, column=1, sticky="w", padx=(6, 12), pady=(6, 0))
        self.vendor_entry.insert(0, "1")

        self.run_button = tk.Button(frame, text="Run RFQ Workflow", command=self.start_pipeline)
        self.run_button.grid(row=1, column=2, sticky="w", padx=(0, 12), pady=(6, 0))

        self.open_qrfs_button = tk.Button(frame, text="Open RFQ PDFs", command=self.open_rfq_pdfs, state="disabled")
        self.open_qrfs_button.grid(row=2, column=0, sticky="w", pady=(10, 0))

        self.open_pdf_button = tk.Button(frame, text="Open PO PDF", command=self.open_pdf, state="disabled")
        self.open_pdf_button.grid(row=2, column=1, sticky="w", pady=(10, 0))

        self.open_json_button = tk.Button(frame, text="Open PO JSON", command=self.open_json, state="disabled")
        self.open_json_button.grid(row=2, column=2, sticky="w", pady=(10, 0))

        self.status_label = tk.Label(frame, text="Ready", anchor="w")
        self.status_label.grid(row=3, column=0, columnspan=3, sticky="we", pady=(10, 0))

        self.output_text = scrolledtext.ScrolledText(self, wrap="word", state="disabled", font=("Consolas", 10))
        self.output_text.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    def start_pipeline(self):
        self.output_text.configure(state="normal")
        self.output_text.delete("1.0", tk.END)
        self.output_text.configure(state="disabled")

        self.run_button.configure(state="disabled")
        self.status_label.configure(text="Running pipeline...")
        self.open_qrfs_button.configure(state="disabled")
        self.open_pdf_button.configure(state="disabled")
        self.open_json_button.configure(state="disabled")

        doc_name = self.doc_entry.get().strip() or "sample_requirement_doc.pdf"
        auto = self.auto_var.get()
        vendor_selection = None
        vendor_text = self.vendor_entry.get().strip()
        if vendor_text.isdigit():
            vendor_selection = int(vendor_text)
            auto = False

        thread = threading.Thread(target=self._run_pipeline, args=(doc_name, auto, vendor_selection), daemon=True)
        thread.start()

    def _run_pipeline(self, doc_name, auto, vendor_selection):
        old_stdout = sys.stdout
        sys.stdout = TextRedirector(self.output_text)
        try:
            result = self.workflow_module.run_pipeline(doc_name=doc_name, auto=auto, vendor_selection=vendor_selection)
            self._on_pipeline_complete(result)
        except Exception as exc:
            print(f"Error: {exc}\n")
        finally:
            sys.stdout = old_stdout
            self.after(0, self._pipeline_finished)

    def _on_pipeline_complete(self, result):
        self.last_rfq = result.get("rfq")
        self.last_rfq_pdfs = self.last_rfq.get("rfq_pdf_paths", []) if self.last_rfq else []
        po = result.get("po")
        if po:
            self.last_po = po.get("po_id")
            self.last_po_json = os.path.join(SCRIPT_DIR, "rfq_bot_data", "orders", f"{self.last_po}.json")
            self.last_po_pdf = po.get("pdf_path")
            self.after(0, lambda: self.open_qrfs_button.configure(state="normal" if self.last_rfq_pdfs else "disabled"))
            self.after(0, lambda: self.open_pdf_button.configure(state="normal"))
            self.after(0, lambda: self.open_json_button.configure(state="normal"))
            self.after(0, lambda: self.status_label.configure(text=f"Completed: {self.last_po}"))
        else:
            self.after(0, lambda: self.status_label.configure(text="Completed with no PO result."))

    def _pipeline_finished(self):
        self.run_button.configure(state="normal")

    def open_rfq_pdfs(self):
        if self.last_rfq_pdfs:
            missing = [path for path in self.last_rfq_pdfs if not os.path.exists(path)]
            if missing:
                messagebox.showwarning("File missing", f"The following RFQ PDFs are missing:\n{chr(10).join(missing)}")
                return
            for path in self.last_rfq_pdfs:
                os.startfile(path)
        else:
            messagebox.showwarning("File missing", "No RFQ PDF files available yet.")

    def open_pdf(self):
        if self.last_po_pdf and os.path.exists(self.last_po_pdf):
            os.startfile(self.last_po_pdf)
        else:
            messagebox.showwarning("File missing", "No PO PDF file available yet.")

    def open_json(self):
        if self.last_po_json and os.path.exists(self.last_po_json):
            os.startfile(self.last_po_json)
        else:
            messagebox.showwarning("File missing", "No JSON file available yet.")


if __name__ == "__main__":
    workflow_module = load_workflow_module(BOT_PATH)
    app = RFQGui(workflow_module)
    app.mainloop()
