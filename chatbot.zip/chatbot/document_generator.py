#!/usr/bin/env python3
"""
document_generator.py
======================
Generates Purchase Order (PO) and Request for Quotation (RFQ) PDF documents
styled after the DynTek Engineering letterhead format:

    - Company name/logo block (top-left) + address/NTN (top-right)
    - Shipping address (left) + Buyer/Vendor block (right)
    - Centered document title with number (e.g. "Purchase Order #P00017")
    - Order date / expected arrival row
    - Orange-header line-items table (Description, Qty, Unit Price, Disc, Taxes, Amount)
    - Footer with company address + page number

Used by rfq_workflow_bot.py to turn RFQ/PO dict objects into real documents.
"""

import os
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, HRFlowable
)

# ----------------------------------------------------------------------
# Company profile (edit these to match your real company details)
# ----------------------------------------------------------------------
COMPANY = {
    "name": "DynTek Engineering",
    "address_lines": [
        "Block 11, Alpha Techno Square, Old International Airport,",
        "Rawalpindi, Pakistan",
    ],
    "ntn": "NTN: 9694521-0",
    "shipping_label": "Shipping address",
    "shipping_lines": [
        "DynTek Warehouse",
        "Block 11, Alpha Techno Square Old Airport Rawalpindi",
        "Rawalpindi IS/ICT 94134",
        "Pakistan",
        "+92515405005",
    ],
}

NAVY = colors.HexColor("#1F3864")
ORANGE = colors.HexColor("#C0622A")
LIGHT_GREY = colors.HexColor("#F2F2F2")


def _styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="CompanyName", fontName="Helvetica-Bold",
                               fontSize=16, textColor=NAVY, leading=18))
    styles.add(ParagraphStyle(name="CompanyTag", fontName="Helvetica-Oblique",
                               fontSize=8, textColor=colors.grey))
    styles.add(ParagraphStyle(name="AddrRight", fontName="Helvetica",
                               fontSize=9, alignment=TA_RIGHT, leading=12))
    styles.add(ParagraphStyle(name="AddrLeft", fontName="Helvetica",
                               fontSize=9, alignment=TA_LEFT, leading=12))
    styles.add(ParagraphStyle(name="DocTitle", fontName="Helvetica-Bold",
                               fontSize=18, alignment=TA_CENTER, textColor=ORANGE,
                               spaceBefore=14, spaceAfter=14))
    styles.add(ParagraphStyle(name="SmallLabel", fontName="Helvetica-Bold",
                               fontSize=8, textColor=colors.grey))
    styles.add(ParagraphStyle(name="SmallValue", fontName="Helvetica",
                               fontSize=9))
    styles.add(ParagraphStyle(name="FooterAddr", fontName="Helvetica",
                               fontSize=7.5, alignment=TA_CENTER, textColor=colors.grey))
    return styles


def _header_block(styles):
    """Top block: Company name (left) + address & NTN (right)."""
    left = Paragraph(f"{COMPANY['name']}<br/>"
                      f"<font size=8 color='grey'><i>Engineering</i></font>",
                      styles["CompanyName"])
    right_text = "<br/>".join([COMPANY["name"]] + COMPANY["address_lines"] + [COMPANY["ntn"]])
    right = Paragraph(right_text, styles["AddrRight"])

    table = Table([[left, right]], colWidths=[3.2 * inch, 4.0 * inch])
    table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    return table


def _parties_block(styles, left_label, left_lines, right_label, right_lines):
    """Two-column block, e.g. Shipping address (left) vs Buyer/Vendor (right)."""
    left = Paragraph(
        f"<b>{left_label}</b><br/>" + "<br/>".join(left_lines), styles["AddrLeft"]
    )
    right = Paragraph(
        f"<b>{right_label}</b><br/>" + "<br/>".join(right_lines), styles["AddrLeft"]
    )
    table = Table([[left, right]], colWidths=[3.2 * inch, 4.0 * inch])
    table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    return table


def _meta_row(styles, fields: dict):
    """A boxed row of label/value pairs, e.g. Buyer | Order Date | Expected Arrival."""
    cells = []
    for label, value in fields.items():
        cells.append(Paragraph(f"<font size=7 color='grey'><b>{label}</b></font><br/>"
                                f"<font size=9>{value}</font>", styles["SmallValue"]))
    col_width = 7.2 * inch / len(cells)
    table = Table([cells], colWidths=[col_width] * len(cells))
    table.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#D9D9D9")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D9D9D9")),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F7F9FC")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
    ]))
    return table


def _footer(canvas_obj, doc):
    canvas_obj.saveState()
    canvas_obj.setFont("Helvetica", 7.5)
    canvas_obj.setFillColor(colors.grey)
    text = " ".join(COMPANY["address_lines"])
    canvas_obj.drawCentredString(letter[0] / 2, 0.6 * inch, text)
    canvas_obj.drawCentredString(letter[0] / 2, 0.45 * inch,
                                  f"Page {doc.page}")
    canvas_obj.restoreState()


# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------
def generate_po_pdf(po: dict, vendor_address: str, output_path: str) -> str:
    """Render a Purchase Order dict (as produced by rfq_workflow_bot) to PDF."""
    styles = _styles()
    doc = SimpleDocTemplate(output_path, pagesize=letter,
                             topMargin=0.6 * inch, bottomMargin=0.9 * inch,
                             leftMargin=0.7 * inch, rightMargin=0.7 * inch)
    story = []

    story.append(_header_block(styles))
    story.append(Spacer(1, 18))
    story.append(_parties_block(
        styles,
        "Shipping address", COMPANY["shipping_lines"],
        "Vendor", [po["vendor"], vendor_address],
    ))
    story.append(Paragraph(f"Purchase Order #{po['po_id']}", styles["DocTitle"]))

    created = po.get("created_at", datetime.now().isoformat())[:10]
    story.append(_meta_row(styles, {
        "Buyer": COMPANY["name"],
        "Order Date": created,
        "Lead Time": f"{po['lead_time_days']} days",
    }))
    story.append(Spacer(1, 16))

    table_data = [["DESCRIPTION", "QTY", "UNIT PRICE", "AMOUNT"]]
    table_data.append([
        po["item"],
        f"{po['quantity']:.2f} Units" if isinstance(po["quantity"], float) else f"{po['quantity']} Units",
        f"{po['unit_price']:.2f}",
        f"{po['total_price']:.2f}",
    ])
    line_table = Table(table_data, colWidths=[3.3 * inch, 1.3 * inch, 1.3 * inch, 1.3 * inch])
    line_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), ORANGE),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D9D9D9")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GREY]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(line_table)
    story.append(Spacer(1, 10))

    total_table = Table([["TOTAL", f"Rs. {po['total_price']:.2f}"]],
                         colWidths=[5.9 * inch, 1.3 * inch])
    total_table.setStyle(TableStyle([
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("TEXTCOLOR", (0, 0), (-1, -1), NAVY),
        ("LINEABOVE", (0, 0), (-1, 0), 1, NAVY),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(total_table)
    story.append(Spacer(1, 20))

    tc = po.get("terms_and_conditions", {})
    if tc:
        story.append(Paragraph("<b>Terms &amp; Conditions</b>", styles["Normal"]))
        story.append(Spacer(1, 4))
        for label, value in tc.items():
            nice_label = label.replace("_", " ").title()
            story.append(Paragraph(f"&#8226; <b>{nice_label}:</b> {value}", styles["Normal"]))

    story.append(Spacer(1, 16))
    story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor("#D9D9D9")))
    story.append(Spacer(1, 4))
    story.append(Paragraph(f"<font size=8 color='grey'>Status: {po['status']} &nbsp;|&nbsp; "
                            f"RFQ Reference: {po['rfq_id']}</font>", styles["Normal"]))

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return output_path


def generate_rfq_pdf(rfq: dict, vendor_name: str, output_path: str) -> str:
    """Render an RFQ dict (as produced by rfq_workflow_bot) to PDF."""
    styles = _styles()
    doc = SimpleDocTemplate(output_path, pagesize=letter,
                             topMargin=0.6 * inch, bottomMargin=0.9 * inch,
                             leftMargin=0.7 * inch, rightMargin=0.7 * inch)
    story = []

    story.append(_header_block(styles))
    story.append(Spacer(1, 18))
    story.append(_parties_block(
        styles,
        "Shipping address", COMPANY["shipping_lines"],
        "Vendor", [vendor_name],
    ))
    story.append(Paragraph(f"Request for Quotation {rfq['rfq_id']}", styles["DocTitle"]))
    story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
    story.append(Spacer(1, 12))

    table_data = [["DESCRIPTION", "SPECIFICATION", "REQUIRED BY", "QTY"]]
    table_data.append([
        rfq["item"],
        rfq["specification"],
        rfq["required_by"],
        f"{rfq['quantity']} Units",
    ])
    line_table = Table(table_data, colWidths=[1.8 * inch, 2.7 * inch, 1.3 * inch, 1.4 * inch])
    line_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), ORANGE),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN", (2, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D9D9D9")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(line_table)
    story.append(Spacer(1, 20))
    story.append(Paragraph(
        "<font size=9>Kindly submit your best quotation, including unit price, "
        "lead time, and applicable warranty/service terms, by return.</font>",
        styles["Normal"]))

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return output_path


if __name__ == "__main__":
    # quick standalone smoke test
    sample_rfq = {
        "rfq_id": "RFQ-TEST0001",
        "item": "Industrial Steel Bracket",
        "quantity": 100,
        "specification": "ASTM A36, Zinc-plated, 5mm thickness",
        "required_by": "2026-07-28",
    }
    sample_po = {
        "po_id": "PO-TEST0001",
        "rfq_id": "RFQ-TEST0001",
        "item": "Industrial Steel Bracket",
        "quantity": 100,
        "vendor": "Beta Fabrication Ltd.",
        "unit_price": 5.04,
        "total_price": 504.0,
        "lead_time_days": 11,
        "terms_and_conditions": {
            "payment_terms": "50% advance, 50% on delivery",
            "delivery_terms": "FOB destination",
            "warranty": "12 months manufacturing defects",
            "penalty_clause": "1% deduction per week of delay",
        },
        "status": "PLACED",
        "created_at": datetime.now().isoformat(),
    }
    os.makedirs("test_docs", exist_ok=True)
    generate_rfq_pdf(sample_rfq, "Beta Fabrication Ltd.", "test_docs/sample_RFQ.pdf")
    generate_po_pdf(sample_po, "Islamabad, Pakistan", "test_docs/sample_PO.pdf")
    print("Generated test_docs/sample_RFQ.pdf and test_docs/sample_PO.pdf")
