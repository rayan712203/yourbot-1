#!/usr/bin/env python3
"""
RFQ Workflow Bot (Dummy / Test Version)
========================================
Simulates the flow:

    Doc -> Data -> RFQ -> Send
                            |
                      Quote Received
                        /         \
                Data file of      CST (Comparative
                Quotation          Statement)
                                       |
                              Decision + Purchase Order
                                       |
                              T&Cs -> Order placed (bot)

Everything here uses fake/dummy data and local JSON "files" so you can
test the pipeline end-to-end without any real vendor APIs.

RFQ and PO are also rendered as branded PDF documents (see document_generator.py)
so you can preview exactly what would be sent to a vendor / filed internally.
"""

import argparse
import json
import os
import random
import uuid
from datetime import datetime, timedelta
from typing import Optional

from document_generator import generate_rfq_pdf, generate_po_pdf

DATA_DIR = "rfq_bot_data"
QUOTATIONS_DIR = os.path.join(DATA_DIR, "quotations")
ORDERS_DIR = os.path.join(DATA_DIR, "orders")
DOCS_DIR = os.path.join(DATA_DIR, "documents")

for d in (DATA_DIR, QUOTATIONS_DIR, ORDERS_DIR, DOCS_DIR):
    os.makedirs(d, exist_ok=True)


# ----------------------------------------------------------------------
# Step 1: Doc -> Data
# ----------------------------------------------------------------------
def extract_data_from_doc(doc_name: str) -> dict:
    """
    Dummy 'document parsing' step.
    In a real system this would OCR / parse a PDF or Word doc.
    Here we just fabricate structured data.
    """
    print(f"\n[1] Reading document: {doc_name}")
    data = {
        "item": "Industrial Steel Bracket",
        "quantity": random.choice([100, 250, 500]),
        "specification": "ASTM A36, Zinc-plated, 5mm thickness",
        "required_by": (datetime.now() + timedelta(days=21)).strftime("%Y-%m-%d"),
        "source_doc": doc_name,
    }
    print(f"    -> Extracted data: {json.dumps(data, indent=2)}")
    return data


# ----------------------------------------------------------------------
# Step 2: Data -> RFQ -> Send
# ----------------------------------------------------------------------
def build_rfq(data: dict) -> dict:
    rfq = {
        "rfq_id": f"RFQ-{uuid.uuid4().hex[:8].upper()}",
        "item": data["item"],
        "quantity": data["quantity"],
        "specification": data["specification"],
        "required_by": data["required_by"],
        "created_at": datetime.now().isoformat(),
        "status": "DRAFT",
    }
    print(f"\n[2] Built RFQ: {rfq['rfq_id']}")
    return rfq


def send_rfq(rfq: dict, vendors: list) -> dict:
    rfq["status"] = "SENT"
    rfq["sent_to"] = [v["name"] for v in vendors]
    print(f"\n[3] Sending {rfq['rfq_id']} to vendors: {', '.join(rfq['sent_to'])}")

    # Generate one branded RFQ PDF per vendor
    rfq_pdf_paths = []
    for v in vendors:
        path = os.path.join(DOCS_DIR, f"{rfq['rfq_id']}_{v['name'].replace(' ', '_')}.pdf")
        generate_rfq_pdf(rfq, v["name"], path)
        rfq_pdf_paths.append(path)
    rfq["sent_to"] = [v["name"] for v in vendors]
    rfq["rfq_pdf_paths"] = rfq_pdf_paths
    print(f"    -> RFQ PDFs generated in {DOCS_DIR}/")
    return rfq


# ----------------------------------------------------------------------
# Step 3: Quote Received -> fan out to (a) Quotation file, (b) CST
# ----------------------------------------------------------------------
DUMMY_VENDORS = [
    {"name": "Alpha Metals Co.", "reliability": 0.9},
    {"name": "Beta Fabrication Ltd.", "reliability": 0.8},
    {"name": "Gamma Steel Works", "reliability": 0.7},
    {"name": "Delta Industrial Supply", "reliability": 0.85},
]


def receive_quotes(rfq: dict, vendors: list) -> list:
    """Simulate vendors responding with quotes."""
    print(f"\n[4] Quotes received for {rfq['rfq_id']}:")
    quotes = []
    for v in vendors:
        unit_price = round(random.uniform(4.5, 9.5), 2)
        lead_time_days = random.randint(5, 25)
        quality_score = round(random.uniform(6.0, 10.0), 1)   # out of 10
        service_score = round(random.uniform(6.0, 10.0), 1)   # out of 10
        quote = {
            "quote_id": f"QT-{uuid.uuid4().hex[:6].upper()}",
            "rfq_id": rfq["rfq_id"],
            "vendor": v["name"],
            "unit_price": unit_price,
            "total_price": round(unit_price * rfq["quantity"], 2),
            "lead_time_days": lead_time_days,
            "quality_score": quality_score,
            "service_score": service_score,
            "received_at": datetime.now().isoformat(),
        }
        quotes.append(quote)
        print(f"    - {v['name']}: ${quote['total_price']} | "
              f"{lead_time_days}d lead time | quality {quality_score}/10 | service {service_score}/10")
    return quotes


def file_quotations(rfq: dict, quotes: list):
    """Branch A: Data file of Quotation -> save each quote to disk."""
    path = os.path.join(QUOTATIONS_DIR, f"{rfq['rfq_id']}_quotes.json")
    with open(path, "w") as f:
        json.dump(quotes, f, indent=2)
    print(f"\n[5a] Filed {len(quotes)} quotations -> {path}")
    return path


# ----------------------------------------------------------------------
# Branch B: Comparative Statement (CST)
# ----------------------------------------------------------------------
def build_cst(rfq: dict, quotes: list) -> list:
    """
    Comparative Statement: rank vendors on quality, service, timing (lead time),
    and price (feasibility), using simple weighted scoring.
    """
    print(f"\n[5b] Building Comparative Statement (CST) for {rfq['rfq_id']}")

    if not quotes:
        return []

    max_price = max(q["total_price"] for q in quotes)
    min_price = min(q["total_price"] for q in quotes)
    max_lead = max(q["lead_time_days"] for q in quotes)
    min_lead = min(q["lead_time_days"] for q in quotes)

    weights = {"price": 0.35, "timing": 0.20, "quality": 0.25, "service": 0.20}

    cst = []
    for q in quotes:
        # Normalize: lower price/lead time is better -> invert to 0-10 scale
        price_score = 10 * (max_price - q["total_price"]) / (max_price - min_price) if max_price != min_price else 10
        timing_score = 10 * (max_lead - q["lead_time_days"]) / (max_lead - min_lead) if max_lead != min_lead else 10

        composite = (
            weights["price"] * price_score
            + weights["timing"] * timing_score
            + weights["quality"] * q["quality_score"]
            + weights["service"] * q["service_score"]
        )
        cst.append({
            "vendor": q["vendor"],
            "quote_id": q["quote_id"],
            "total_price": q["total_price"],
            "lead_time_days": q["lead_time_days"],
            "quality_score": q["quality_score"],
            "service_score": q["service_score"],
            "price_score": round(price_score, 2),
            "timing_score": round(timing_score, 2),
            "composite_score": round(composite, 2),
        })

    cst.sort(key=lambda x: x["composite_score"], reverse=True)

    print(f"\n    {'Rank':<5}{'Vendor':<26}{'Price':<10}{'Lead(d)':<9}{'Qual':<6}{'Serv':<6}{'Score':<7}")
    for i, row in enumerate(cst, 1):
        print(f"    {i:<5}{row['vendor']:<26}${row['total_price']:<9}{row['lead_time_days']:<9}"
              f"{row['quality_score']:<6}{row['service_score']:<6}{row['composite_score']:<7}")

    cst_path = os.path.join(DATA_DIR, f"{rfq['rfq_id']}_CST.json")
    with open(cst_path, "w") as f:
        json.dump(cst, f, indent=2)
    print(f"\n    CST saved -> {cst_path}")
    return cst


# ----------------------------------------------------------------------
# Step 4: Decision -> Purchase Order -> T&Cs -> Order placed (bot)
# ----------------------------------------------------------------------
def decide_vendor(cst: list, auto: bool = False, vendor_selection: Optional[int] = None) -> dict:
    """
    Decision step. Bot recommends the top-ranked vendor from the CST,
    but final choice can be confirmed/overridden by the user.
    """
    if not cst:
        raise ValueError("No CST data to decide from.")

    recommended = cst[0]
    print(f"\n[6] Bot recommendation: {recommended['vendor']} "
          f"(score {recommended['composite_score']}/10)")

    if auto:
        chosen = recommended
    elif vendor_selection is not None:
        idx = vendor_selection - 1 if 1 <= vendor_selection <= len(cst) else 0
        chosen = cst[idx]
        print(f"    -> Vendor selection provided: {vendor_selection}")
    else:
        print("\n    Vendor options:")
        for i, row in enumerate(cst, 1):
            print(f"      {i}. {row['vendor']} (score {row['composite_score']})")
        choice = input(f"    Select vendor number [default 1 = recommended]: ").strip()
        idx = int(choice) - 1 if choice.isdigit() and 1 <= int(choice) <= len(cst) else 0
        chosen = cst[idx]

    print(f"    -> Selected vendor: {chosen['vendor']}")
    return chosen


def create_purchase_order(rfq: dict, vendor_choice: dict) -> dict:
    po = {
        "po_id": f"PO-{uuid.uuid4().hex[:8].upper()}",
        "rfq_id": rfq["rfq_id"],
        "item": rfq["item"],
        "quantity": rfq["quantity"],
        "vendor": vendor_choice["vendor"],
        "unit_price": round(vendor_choice["total_price"] / rfq["quantity"], 2),
        "total_price": vendor_choice["total_price"],
        "lead_time_days": vendor_choice["lead_time_days"],
        "terms_and_conditions": {
            "payment_terms": "50% advance, 50% on delivery",
            "delivery_terms": "FOB destination",
            "warranty": "12 months manufacturing defects",
            "penalty_clause": "1% deduction per week of delay",
        },
        "status": "PLACED",
        "created_at": datetime.now().isoformat(),
    }
    json_path = os.path.join(ORDERS_DIR, f"{po['po_id']}.json")
    with open(json_path, "w") as f:
        json.dump(po, f, indent=2)

    pdf_path = os.path.join(DOCS_DIR, f"{po['po_id']}.pdf")
    generate_po_pdf(po, vendor_address="Pakistan", output_path=pdf_path)
    po["pdf_path"] = pdf_path

    print(f"\n[7] Purchase Order created & order placed by bot")
    print(f"    JSON -> {json_path}")
    print(f"    PDF  -> {pdf_path}")
    print(f"    PO: {po['po_id']} | Vendor: {po['vendor']} | Total: ${po['total_price']}")
    return po


# ----------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------
def run_pipeline(doc_name: str = "sample_requirement_doc.pdf", auto: bool = False,
                  vendor_selection: Optional[int] = None) -> dict:
    print("=" * 70)
    print("RFQ WORKFLOW BOT - DUMMY RUN")
    print("=" * 70)

    data = extract_data_from_doc(doc_name)
    rfq = build_rfq(data)
    rfq = send_rfq(rfq, DUMMY_VENDORS)

    quotes = receive_quotes(rfq, DUMMY_VENDORS)
    file_quotations(rfq, quotes)          # Branch A
    cst = build_cst(rfq, quotes)          # Branch B

    vendor_choice = decide_vendor(cst, auto=auto, vendor_selection=vendor_selection)
    po = create_purchase_order(rfq, vendor_choice)

    print("\n" + "=" * 70)
    print("PIPELINE COMPLETE")
    print("=" * 70)
    return {"rfq": rfq, "quotes": quotes, "cst": cst, "po": po}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="RFQ workflow bot dummy runner.")
    parser.add_argument("--doc", default="sample_requirement_doc.pdf",
                         help="Document name or source to parse.")
    parser.add_argument("--auto", action="store_true",
                         help="Automatically accept the recommended vendor.")
    parser.add_argument("--vendor", type=int,
                         help="Select a specific vendor by ranking number.")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_pipeline(doc_name=args.doc, auto=args.auto, vendor_selection=args.vendor)
